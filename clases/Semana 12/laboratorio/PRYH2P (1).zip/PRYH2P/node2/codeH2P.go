// topología anillo o circular //TCP
package main

import (
	"bufio"
	"fmt"
	"log"
	"net"
	"os"
	"strconv"
	"strings"
)

// variables globales
var dirLocal string ///IP:PORT
var dirRemoto string
var num int

// rol servidor / Cliente
func main() {
	dirLocal = "172.20.0.3:9091"
	dirRemoto = "172.20.0.4:9091"

	fmt.Println(dirLocal)
	fmt.Println(dirRemoto)
	///////////////////////////////////////////////
	//Rol de servidor
	//////////////////////////////////////////////
	//exponemos un puerto -> puerto local
	ls, err2 := net.Listen("tcp", dirLocal)
	errorLectura(err2)
	defer ls.Close()
	//escucha constante
	for {
		conn, err3 := ls.Accept()
		errorLectura(err3)
		go handle(conn)
	}
}

// Funciones propias
func errorLectura(err error) {
	if err != nil {
		log.Fatal(err.Error())
		os.Exit(-1) //finalizar el programa
	}
}

func handle(conn net.Conn) {
	defer conn.Close()
	///////////////////////
	//lógica del servicio
	//////////////////////
	strNum, _ := bufio.NewReader(conn).ReadString('\n')
	strNum = strings.TrimSpace(strNum)
	num, _ = strconv.Atoi(strNum)
	fmt.Printf("Llegó el número %d\n", num)
	//comparación
	if num == 0 {
		fmt.Printf("Boommmm!\n")
	} else {
		//enviar el nro-1 al nodo remoto
		enviar(num - 1)
	}
}

func enviar(num int) {
	conn, _ := net.Dial("tcp", dirRemoto)
	defer conn.Close()
	//envío
	fmt.Fprintln(conn, num)
}

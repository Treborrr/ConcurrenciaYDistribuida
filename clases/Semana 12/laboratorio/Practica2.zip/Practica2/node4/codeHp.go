// ejercicio HP distribuido
// topología de red tipo Anillo o Circular TCP
package main

import (
	"bufio"
	"fmt"
	"log"
	"net"
	"os"
	"strconv"
	"strings"
)

var dirLocal string
var dirRemoto string
var num int

// Rol de cliente y servidor en el mismo programa, dependiendo de la configuración o argumentos pasados al ejecutar el programa
func main() {
	dirLocal = "172.20.0.5:9051"
	dirRemoto = "172.20.0.2:9051"

	// Aquí iría el código para establecer la conexión y realizar las operaciones necesarias
	ln, err := net.Listen("tcp", dirLocal)
	if err != nil {
		log.Fatal(err)
	}
	defer ln.Close()
	fmt.Printf("Servidor escuchando en %s\n", dirLocal)
	for {
		conn, err := ln.Accept()
		errorLectura(err)
		go handle(conn)
	}
}

// Funciones propias
func errorLectura(err error) {
	if err != nil {
		log.Fatal(err.Error())
		os.Exit(-1) //finalizar el programa
	}
}

func handle(conn net.Conn) {
	defer conn.Close()
	///////////////////////
	//lógica del servicio
	//////////////////////
	strNum, _ := bufio.NewReader(conn).ReadString('\n')
	strNum = strings.TrimSpace(strNum)
	num, _ = strconv.Atoi(strNum)
	fmt.Printf("Llegó el número %d\n", num)
	//comparación
	if num == 0 {
		fmt.Printf("Boommmm!\n")
	} else {
		//enviar el nro-1 al nodo remoto
		enviar(num - 1)
	}
}

func enviar(num int) {
	conn, _ := net.Dial("tcp", dirRemoto)
	defer conn.Close()
	//envío
	fmt.Fprintln(conn, num)
}

package main

import (
	"fmt"
	"log"
	"net"
	"net/http"
)

func handleNumber(w http.ResponseWriter, r *http.Request) {
	// Aquí iría la lógica para manejar la solicitud y enviar una respuesta
	log.Println("Número recibido a través de la API")
	w.WriteHeader(http.StatusOK)

	conn, err := net.Dial("tcp", "172.20.0.2:9051")
	if err != nil {
		log.Println("Error al conectar con el nodo:", err)
		return
	}
	defer conn.Close()

	// Enviar un número de ejemplo al nodo
	num := 1000
	fmt.Fprintf(conn, "%d\n", num)

	log.Printf("Número %d enviado al nodo\n", num)
}

func main() {
	http.HandleFunc("/api/v1/number", handleNumber)
	log.Fatal(http.ListenAndServe(":9151", nil))
}
